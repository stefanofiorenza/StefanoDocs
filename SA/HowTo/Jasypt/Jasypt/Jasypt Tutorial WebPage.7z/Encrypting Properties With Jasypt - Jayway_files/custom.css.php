.image100 {
	width:100%;
        height: inherit;
}

.roundteam {
border-radius: 50%; width: 200px; height: 200px; background-color: #00ff00;
}
