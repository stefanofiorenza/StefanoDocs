/* Accent Color */

a,
header #logo a:hover,
header #logo a:focus,
header #logo a:active,
#latest-posts .post-name .entry-title a:hover,
.entry-meta.entry-header a:hover,
.entry-meta.entry-header a:active,
.entry-meta.entry-header a:focus,
.standard-blog .post-name .entry-title a:hover,
.masonry-blog .post-name .entry-title a:hover,
.center-blog .post-name .entry-title a:hover,
.comment-author cite a:hover,
.comment-meta a:hover,
#commentform span.required,
#footer-credits p a,
.social_widget a i,
.dropmenu-active ul li a:hover,
.color-text,
.dropcap-color,
.social-icons li a:hover i,
.counter-number .count-number-icon {
	color: #41b6e6;
}

#menu ul .sub-menu li a:hover {
	color: #41b6e6 !important;
}

.overlay-bg,
.overlay-bg-fill,
.item-project i,
.standard-blog .post-link,
.standard-blog .post-quote,
.masonry-blog .post-link,
.masonry-blog .post-quote,
.center-blog .post-link,
.center-blog .post-quote,
.badge_author,
#error-page .error-btn,
.social_widget a:hover,
.tooltip-inner,
.highlight-text,
.progress-bar .bar,
.pricing-table.selected .price,
.pricing-table.selected .confirm,
.mejs-overlay:hover .mejs-overlay-button,
.mejs-controls .mejs-time-rail .mejs-time-current,
.mejs-controls .mejs-volume-button .mejs-volume-slider .mejs-volume-current,
.mejs-controls .mejs-horizontal-volume-slider .mejs-horizontal-volume-current,
#jpreOverlay,
#jSplash,
#jprePercentage,
.tp-bullets.simplebullets.round .bullet:hover,
.tp-bullets.simplebullets.round .bullet.selected,
.tp-bullets.simplebullets.navbar .bullet:hover,
.tp-bullets.simplebullets.navbar .bullet.selected {
	background-color: #41b6e6;
}

.navigation-projects ul li.prev a:hover,
.navigation-projects ul li.next a:hover,
.navigation-projects ul li.back-page a:hover {
	background-color: #41b6e6;
	border-color: #41b6e6;
}

.wpcf7 .wpcf7-submit:hover,
.wpcf7 .wpcf7-submit:focus,
.wpcf7 .wpcf7-submit:active,
#commentform #submit:hover,
.button-main:hover,
.button-main:active,
.button-main:focus,
.button-main.inverted {
	background-color: #41b6e6;
    border-color: #41b6e6;
}

.wpcf7-form.invalid input.wpcf7-not-valid,
.wpcf7-form.invalid textarea.wpcf7-not-valid,
.wpcf7-form input:focus:invalid:focus,
.wpcf7-form textarea:focus:invalid:focus,
.social_widget a {
	border-color: #41b6e6;
}

.tagcloud a {
	border-color: #41b6e6;
	color: #41b6e6;
}

.tagcloud a:hover,
.tagcloud a:active,
.tagcloud a:focus {
	background-color: #41b6e6;
}

.tooltip.top .tooltip-arrow {
    border-top-color: #41b6e6;
}

.tooltip.right .tooltip-arrow {
    border-right-color: #41b6e6;
}

.tooltip.left .tooltip-arrow {
    border-left-color: #41b6e6;
}

.tooltip.bottom .tooltip-arrow {
    border-bottom-color: #41b6e6;
}

.box .icon.circle-mode-box {
	border-color: rgba(65,182,230, 0.5);
}

.box:hover .icon.circle-mode-box,
.box:active .icon.circle-mode-box,
.box:focus .icon.circle-mode-box {
	border-color: #41b6e6;
	background-color: #41b6e6;
}

.box .icon.circle-mode-box i,
.box.boxed-version .icon-boxed i,
.box .icon.icon-only-mode-box {
	color: #41b6e6;
}


/* Header Colors */

header {
	background-color: #221f1f;
}

header #logo a {
	color: #221f1f;
}

#menu ul a {
	color: #FFFFFF;
}

#menu > ul > li:after {
    border-color: #112f1f;
}

#menu ul a:hover,
#menu ul li.sfHover a,
#menu ul li.current-cat a,
#menu ul li.current_page_item a,
#menu ul li.current-menu-item a,
#menu ul li.current-page-ancestor a,
#menu ul li.current-menu-ancestor a {
    color: #d0df00;
}

#menu ul ul {
	background-color: #222222;
}

#menu ul .sub-menu li a {
	color: #ffffff !important;
	border-color: #221f1f;
}

/* Mobile Dropdown Colors */

#navigation-mobile {
	background-color: #221f1f;
}

#navigation-mobile li a,
#menu-nav-mobile .sub-menu li a {
	color: #ffffff;
}

#navigation-mobile li.has-ul.open > a,
#navigation-mobile li a:hover,
#menu-nav-mobile .sub-menu li a:hover,
#navigation-mobile li.has-ul.open a i,
#navigation-mobile .sub-menu li.has-ul.open a i {
	color: #d0df00;
}

#menu-nav-mobile li,
#menu-nav-mobile ul.sub-menu li {
	border-color: #222222;
}

#navigation-mobile li.has-ul a i,
#navigation-mobile .sub-menu li.has-ul a i {
	color: #ffffff;
}

/* Typography Colors */

body,
a:hover,
a:active,
a:focus,
.entry-meta.entry-header a,
.comment-meta, 
.comment-meta a,
#twitter-feed .tweet_list li .tweet_time a,
.box p,
.dropmenu-active ul li a {
	color: #333333;
}

h1,
h2,
h3,
h4,
h5,
h6,
#latest-posts .post-name .entry-title a,
.standard-blog .post-name .entry-title a,
.masonry-blog .post-name .entry-title a,
.center-blog .post-name .entry-title a,
.comment-author cite, 
.comment-author cite a,
.dropmenu p,
.accordion-heading .accordion-toggle,
.nav > li > a,
.nav-tabs > li.active > a, 
.nav-tabs > li.active > a:hover, 
.nav-tabs > li.active > a:focus,
.dropcap,
.easyPieChart,
.pricing-table .price,
.counter-number .number-value {
	color: #221f1f;
}

/* Back To Top Colors */

#back-to-top {
	background-color: #41b6e6;
}

#back-to-top i {
	color: #FFFFFF;
}
